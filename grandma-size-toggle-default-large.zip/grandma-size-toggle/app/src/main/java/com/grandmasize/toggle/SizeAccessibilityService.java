package com.grandmasize.toggle;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Automates the visible ColorOS Settings screens instead of writing protected
 * settings directly. Intended for the OPPO A15 / ColorOS 7.x layout, with
 * text-based fallbacks for small firmware variations.
 */
public class SizeAccessibilityService extends AccessibilityService {
    private static final String SETTINGS_PACKAGE = "com.android.settings";
    private static final long STEP_DELAY_MS = 450L;
    private static final long TIMEOUT_MS = 12000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private boolean running = false;
    private int currentStep = 0;
    private long startedAt = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {
        if (prefs == null) prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);

        if (!prefs.getBoolean(MainActivity.KEY_PENDING, false)) return;
        if (!SETTINGS_PACKAGE.equals(event.getPackageName())) return;

        if (!running) {
            running = true;
            currentStep = 0;
            startedAt = System.currentTimeMillis();
            handler.postDelayed(this::advance, STEP_DELAY_MS);
        }
    }

    @Override
    public void onInterrupt() {
        // Nothing to clean up; the next launch can retry.
    }

    private void advance() {
        if (!prefs.getBoolean(MainActivity.KEY_PENDING, false)) {
            stopRun(false);
            return;
        }
        if (System.currentTimeMillis() - startedAt > TIMEOUT_MS) {
            toast("Size change timed out. Try again from the app icon.");
            stopRun(true);
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isSettingsWindow()) {
            handler.postDelayed(this::advance, STEP_DELAY_MS);
            return;
        }

        int preset = prefs.getInt(MainActivity.KEY_PRESET, MainActivity.PRESET_DEFAULT);
        boolean acted;
        switch (currentStep) {
            case 0:
                acted = openFontAndDisplaySize(root);
                if (acted) currentStep = 1;
                break;
            case 1:
                acted = setSliderForTarget(root, true, fractionForPreset(preset));
                if (acted) currentStep = 2;
                break;
            case 2:
                acted = setSliderForTarget(root, false, fractionForPreset(preset));
                if (acted) currentStep = 3;
                break;
            case 3:
                acted = tapApplyIfPresent(root);
                if (acted) currentStep = 4;
                else currentStep = 4; // Apply may be automatic on some ColorOS builds.
                break;
            default:
                finishRun();
                return;
        }

        handler.postDelayed(this::advance, acted ? STEP_DELAY_MS * 2 : STEP_DELAY_MS);
    }

    private boolean isSettingsWindow() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        CharSequence pkg = root.getPackageName();
        return SETTINGS_PACKAGE.equals(pkg);
    }

    /** Open the combined Font & display size screen from Display & brightness. */
    private boolean openFontAndDisplaySize(AccessibilityNodeInfo root) {
        String[] preferred = {
                "font & display size",
                "font and display size",
                "font size",
                "display size"
        };
        AccessibilityNodeInfo node = findTextContainsAny(root, preferred);
        if (node != null && performClick(node)) return true;

        // Some builds initially show a scrollable Display & Brightness list.
        if (scrollDownOnce(root)) return false;
        return false;
    }

    /**
     * targetFont=true chooses the upper/first slider, targetFont=false chooses
     * the other slider. If only one slider is visible, use text proximity to
     * determine whether it is font or display size.
     */
    private boolean setSliderForTarget(AccessibilityNodeInfo root, boolean targetFont, float fraction) {
        List<AccessibilityNodeInfo> sliders = collectSliders(root);
        if (sliders.isEmpty()) return false;

        Collections.sort(sliders, new Comparator<AccessibilityNodeInfo>() {
            @Override public int compare(AccessibilityNodeInfo a, AccessibilityNodeInfo b) {
                Rect ra = bounds(a);
                Rect rb = bounds(b);
                return Integer.compare(ra.top, rb.top);
            }
        });

        AccessibilityNodeInfo chosen = chooseSlider(root, sliders, targetFont);
        if (chosen == null) return false;

        if (setProgress(chosen, fraction)) return true;
        return tapSliderAt(chosen, fraction);
    }

    private AccessibilityNodeInfo chooseSlider(AccessibilityNodeInfo root,
                                                List<AccessibilityNodeInfo> sliders,
                                                boolean targetFont) {
        if (sliders.size() == 1) return sliders.get(0);

        // Score the slider using the nearest labels in the surrounding tree.
        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        for (AccessibilityNodeInfo slider : sliders) {
            Rect sr = bounds(slider);
            int score = 0;
            List<AccessibilityNodeInfo> labels = collectTextNodes(root);
            for (AccessibilityNodeInfo label : labels) {
                String text = textOf(label);
                if (text == null) continue;
                String lower = text.toLowerCase(Locale.US);
                Rect lr = bounds(label);
                int distance = Math.abs(lr.centerY() - sr.centerY());
                if (lower.contains("font")) {
                    score += targetFont ? Math.max(1, 10000 - distance) : 0;
                }
                if (lower.contains("display")) {
                    score += !targetFont ? Math.max(1, 10000 - distance) : 0;
                }
                if (lower.contains("tamaño") || lower.contains("文字") || lower.contains("サイズ")) {
                    // Harmless broad fallback for translated OEM UI.
                    score += 1;
                }
            }
            if (score > bestScore) {
                bestScore = score;
                best = slider;
            }
        }

        if (best != null && bestScore > 0) return best;
        return targetFont ? sliders.get(0) : sliders.get(sliders.size() - 1);
    }

    private boolean tapApplyIfPresent(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo apply = findTextContainsAny(root,
                new String[]{"apply", "done", "save", "confirm"});
        return apply != null && performClick(apply);
    }

    private float fractionForPreset(int preset) {
        switch (preset) {
            case MainActivity.PRESET_VERY_LARGE:
                return 1.0f;
            default:
                // ColorOS 7.x presents the middle/default position around the center.
                return 0.5f;
        }
    }

    private List<AccessibilityNodeInfo> collectSliders(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> result = new ArrayList<>();
        collectSlidersRecursive(root, result);
        return result;
    }

    private void collectSlidersRecursive(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String cls = node.getClassName() == null ? "" : node.getClassName().toString();
        boolean range = node.getRangeInfo() != null;
        if (range || cls.toLowerCase(Locale.US).contains("seekbar") || cls.toLowerCase(Locale.US).contains("slider")) {
            out.add(node);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectSlidersRecursive(child, out);
        }
    }

    private List<AccessibilityNodeInfo> collectTextNodes(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> result = new ArrayList<>();
        collectTextRecursive(root, result);
        return result;
    }

    private void collectTextRecursive(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (!textOf(node).isEmpty()) out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectTextRecursive(child, out);
        }
    }

    private AccessibilityNodeInfo findTextContainsAny(AccessibilityNodeInfo root, String[] keys) {
        if (root == null) return null;
        String text = textOf(root).toLowerCase(Locale.US);
        for (String key : keys) {
            if (text.contains(key.toLowerCase(Locale.US)) && (root.isClickable() || root.getParent() != null)) {
                return root;
            }
        }
        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTextContainsAny(root.getChild(i), keys);
            if (found != null) return found;
        }
        return null;
    }

    private boolean performClick(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo clickable = node;
        while (clickable != null && !clickable.isClickable()) clickable = clickable.getParent();
        return clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private boolean setProgress(AccessibilityNodeInfo slider, float fraction) {
        AccessibilityNodeInfo.RangeInfo info = slider.getRangeInfo();
        if (info == null) return false;
        float min = info.getMin();
        float max = info.getMax();
        float value = min + (max - min) * fraction;
        return slider.performAction(AccessibilityNodeInfo.ACTION_SET_PROGRESS,
                buildProgressBundle(value));
    }

    private android.os.Bundle buildProgressBundle(float value) {
        android.os.Bundle args = new android.os.Bundle();
        args.putFloat("android.view.accessibility.action.ARGUMENT_PROGRESS_VALUE", value);
        return args;
    }

    private boolean tapSliderAt(AccessibilityNodeInfo slider, float fraction) {
        Rect r = bounds(slider);
        if (r.width() <= 0 || r.height() <= 0) return false;
        float x = r.left + r.width() * fraction;
        float y = r.centerY();
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 80))
                .build();
        return dispatchGesture(gesture, null, null);
    }

    private boolean scrollDownOnce(AccessibilityNodeInfo root) {
        if (root == null) return false;
        AccessibilityNodeInfo scrollable = findScrollable(root);
        return scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isScrollable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findScrollable(node.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private Rect bounds(AccessibilityNodeInfo node) {
        Rect r = new Rect();
        if (node != null) node.getBoundsInScreen(r);
        return r;
    }

    private String textOf(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        if (text == null) text = node.getContentDescription();
        return text == null ? "" : text.toString().trim();
    }

    private void finishRun() {
        prefs.edit().putBoolean(MainActivity.KEY_PENDING, false).apply();
        // Return to the launcher, as requested: the helper app is not left open.
        performGlobalAction(GLOBAL_ACTION_HOME);
        stopRun(false);
    }

    private void stopRun(boolean clearPending) {
        if (clearPending && prefs != null) {
            prefs.edit().putBoolean(MainActivity.KEY_PENDING, false).apply();
        }
        handler.removeCallbacksAndMessages(null);
        running = false;
        currentStep = 0;
    }

    private void toast(String message) {
        handler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show());
    }
}
