package com.grandmasize.toggle;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Toast;
import android.app.Activity;


import java.util.List;

/**
 * One-tap launcher activity.
 *
 * After the accessibility service is enabled, launching this app immediately
 * advances the preset: DEFAULT -> VERY_LARGE -> DEFAULT ...
 * It stores the desired preset and opens Android's Display settings so the
 * accessibility service can operate the visible Settings UI.
 */
public class MainActivity extends Activity {
    static final String PREFS = "grandma_size";
    static final String KEY_PRESET = "preset";
    static final String KEY_PENDING = "pending";

    static final int PRESET_DEFAULT = 0;
    static final int PRESET_VERY_LARGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!isAccessibilityServiceEnabled(this, SizeAccessibilityService.class)) {
            Toast.makeText(this,
                    "Enable Grandma Size in Accessibility, then press the app icon again.",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int current = prefs.getInt(KEY_PRESET, PRESET_DEFAULT);
        // Two-state toggle: Default <-> Very large.
        int next = (current == PRESET_VERY_LARGE) ? PRESET_DEFAULT : PRESET_VERY_LARGE;
        String label = presetLabel(next);

        prefs.edit()
                .putInt(KEY_PRESET, next)
                .putBoolean(KEY_PENDING, true)
                .apply();

        Toast.makeText(this, "Switching to " + label + "…", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (Exception e) {
            // Some vendor builds use a different Settings activity. Fall back to main Settings.
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }

        // The app should disappear immediately; the accessibility service takes over.
        finishAndRemoveTask();
    }

    static String presetLabel(int preset) {
        switch (preset) {
            case PRESET_VERY_LARGE:
                return "Very large";
            default:
                return "Default";
        }
    }

    static boolean isAccessibilityServiceEnabled(Context context, Class<?> serviceClass) {
        try {
            String expected = new ComponentName(context, serviceClass).flattenToString();
            String enabled = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabled)) return false;
            TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
            splitter.setString(enabled);
            while (splitter.hasNext()) {
                String item = splitter.next();
                if (expected.equalsIgnoreCase(item)) return true;
            }
        } catch (Exception ignored) {
            // Some OEM Settings providers can reject reads; treat as disabled.
        }
        return false;
    }
}
