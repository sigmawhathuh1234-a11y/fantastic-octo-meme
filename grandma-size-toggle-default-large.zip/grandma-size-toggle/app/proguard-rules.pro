# Intentionally empty: this app does not use shrinking by default.
