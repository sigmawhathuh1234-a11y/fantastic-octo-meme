# Grandma Size Toggle

One-tap Android helper for an OPPO A15 (ColorOS 7.2 / Android 10) that toggles between exactly two presets:

`Default ↔ Very large`

The launcher activity immediately opens Android's Display settings, then exits. A user-enabled `AccessibilityService` operates the visible Settings UI and returns to the home screen when it finishes.

## Important setup

1. Build and install the debug APK.
2. Launch **Grandma Size** once.
3. Android opens **Accessibility** settings. Enable **Grandma Size Settings Controller**.
4. Return to the home screen.
5. Tap the **Grandma Size** icon whenever the preset should change.

After setup, the normal flow is intended to be a single tap on the app icon. The app itself closes immediately; the accessibility service performs the Settings changes and then returns to Home.

## Preset behavior

The app stores its own last state, so the sequence is:

- first tap: Very large
- second tap: Default
- third tap: Very large
- repeats

The actual slider values are intentionally mapped to the ends and midpoint of the visible ColorOS controls rather than trying to write protected settings directly.

## Why Accessibility

Android's public app APIs do not give a normal third-party app permission to silently rewrite the system display/font settings. This project instead automates the visible Settings interface after the user explicitly enables its AccessibilityService.

## OPPO A15 target

OPPO lists the A15 as **ColorOS 7.2 based on Android 10**. OPPO's current support guidance places font-size controls under **Settings → Display & brightness** for ColorOS 5.2–7.0, and current third-party device guides show **Font & display size** for the Android 10/ColorOS generation. Firmware/menu wording can vary, so the service matches several labels and uses slider/range information where available.

## Building

### GitHub

Push this folder to a repository. The included GitHub Action builds `app-debug.apk` and uploads it as a workflow artifact.

### Local / Termux

With Java and Gradle installed:

```bash
python3 scripts/build.py
```

The debug APK will be at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install from Termux with ADB when a computer/ADB transport is available, or copy the APK to the phone and install it there.

## Notes

- This is intentionally not a root-only app and does not use `settings put` or hidden system APIs.
- The Settings UI is OEM-specific. The implementation is tuned for the OPPO A15/ColorOS family but is defensive about text/slider differences.
- If the phone's firmware uses different translated labels or a different layout, adjust the matching strings in `SizeAccessibilityService.java`.
- Accessibility services can observe UI contents. Only enable this service on a device you trust.
