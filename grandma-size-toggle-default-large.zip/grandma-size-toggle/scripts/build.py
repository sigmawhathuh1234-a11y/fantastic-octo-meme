#!/usr/bin/env python3
"""Build the Android project with an installed Gradle executable."""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main() -> int:
    gradle = shutil.which("gradle")
    if not gradle:
        print("Gradle is not installed. Use Android Studio, install Gradle, or push the repo to GitHub and run the included Action.", file=sys.stderr)
        return 2
    cmd = [gradle, ":app:assembleDebug"]
    print("$", " ".join(cmd))
    return subprocess.call(cmd, cwd=ROOT)

if __name__ == "__main__":
    raise SystemExit(main())
